public class Alumno {
    private String nombre;
    private String apellido;
    private String numeroIdentificacion;
    private String fechaNacimiento;
    private String direccion;

    public Alumno(String nombre, String apellido, String numeroIdentificacion, String fechaNacimiento, String direccion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.numeroIdentificacion = numeroIdentificacion;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
   }
